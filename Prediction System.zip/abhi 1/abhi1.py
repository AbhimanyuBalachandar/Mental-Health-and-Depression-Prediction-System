
import pandas as pd
from sklearn.ensemble import RandomForestClassifier

df = pd.read_csv(r'b_depressed.csv')

# print(df.columns.tolist())

df_new = df.drop(['Survey_id', 'Ville_id'], axis=1)
# print(df_new.columns.tolist())

# df_new.to_csv(r'/content/sample data/preprocesed.csv', index=False)

'''print(df_new.columns.tolist())

print(df_new.shape)
print(df_new.columns.tolist())'''
df_cleaned = df_new.dropna()

# print(df_cleaned.shape)
# print(df_cleaned.columns.tolist())

X = df_cleaned.drop('depressed', axis=1)
y = df_cleaned['depressed']

rf = RandomForestClassifier(n_estimators=100)
rf.fit(X, y)

# Get feature importances
feature_importances = rf.feature_importances_

# Create a DataFrame to display feature rankings
feature_ranking = pd.DataFrame({'Feature': X.columns, 'Importance': feature_importances})
feature_ranking = feature_ranking.sort_values(by='Importance', ascending=False)

# print(feature_ranking.columns.tolist())
print(feature_ranking)

df_afterdrop = df_cleaned.drop(['incoming_business', 'incoming_own_farm','incoming_salary','labor_primary','incoming_no_business','sex','Married','total_members','save_asset','gained_asset'], axis=1)
# print(df_afterdrop.columns.tolist())

# df_afterdrop.to_csv(r'/content/sample data/prepared.csv', index=False)
