import pandas as pd
import xgboost as xgb
from sklearn.model_selection import train_test_split
from scipy import stats
import numpy as np
from sklearn.metrics import accuracy_score

# Load and preprocess your data
df = pd.read_csv('prepared.csv')
df_no_duplicates = df.drop_duplicates()
z_scores = np.abs(stats.zscore(df))
df_no_outliers = df[(z_scores < 3).all(axis=1)]
df = df_no_outliers

# Prepare the data
X = df.drop('depressed', axis=1)
y = df['depressed']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create an XGBoost classifier
xgBoost = xgb.XGBClassifier()

# Train the XGBoost classifier
xgBoost.fit(X_train, y_train)

# Make predictions on the test set
y_pred_xgb = xgBoost.predict(X_test)

# Evaluate the XGBoost model
accuracy = accuracy_score(y_test, y_pred_xgb)
print("Accuracy for XGBoost:", accuracy)
