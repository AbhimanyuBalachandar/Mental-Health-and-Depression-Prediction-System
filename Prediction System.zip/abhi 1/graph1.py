import matplotlib.pyplot as plt

# Sample data
models = ['Random Forest', 'XGBoost', 'Logistic Regression']
accuracy = [0.85, 0.82, 0.78]
precision = [0.88, 0.85, 0.80]
recall = [0.82, 0.78, 0.75]
f1_score = [0.85, 0.80, 0.77]

# Plotting the bar graph
fig, ax = plt.subplots(figsize=(10, 6))

bar_width = 0.2
index = range(len(models))

bar1 = ax.bar(index, accuracy, bar_width, label='Accuracy')
bar2 = ax.bar([i + bar_width for i in index], precision, bar_width, label='Precision')
bar3 = ax.bar([i + 2 * bar_width for i in index], recall, bar_width, label='Recall')
bar4 = ax.bar([i + 3 * bar_width for i in index], f1_score, bar_width, label='F1 Score')

# Adding labels
ax.set_xlabel('Models', fontsize=14)
ax.set_ylabel('Scores', fontsize=14)
ax.set_title('Model Evaluation Metrics', fontsize=16)
ax.set_xticks([i + 1.5 * bar_width for i in index])
ax.set_xticklabels(models)
ax.legend()

# Display the plot
plt.show()
