import pandas as pd
from sklearn.linear_model import LogisticRegression
import xgboost as xgb
from sklearn.model_selection import train_test_split
from scipy import stats
import numpy as np
from sklearn.metrics import accuracy_score
from sklearn.model_selection import GridSearchCV

# Load and preprocess your data
df = pd.read_csv('prepared.csv')

X = df.drop('depressed', axis=1)
y = df['depressed']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create an XGBoost classifier
xgBoost = xgb.XGBClassifier()

# Define the hyperparameter grid for grid search
param_grid = {
    'n_estimators': [100, 200, 300],  # Number of trees 
    'max_depth': [3, 4, 5],         # Maximum tree depth
    'learning_rate': [0.01, 0.1, 0.2],  # Learning rate
    'subsample': [0.7, 0.8, 0.9],   # Fraction of samples used for training each tree
}

# Perform grid search with cross-validation
grid_search = GridSearchCV(estimator=xgBoost, param_grid=param_grid, scoring='accuracy', cv=5)
grid_search.fit(X_train, y_train)

# Get the best hyperparameters from grid search
best_params = grid_search.best_params_

# Train the XGBoost classifier with the best hyperparameters
best_xgb_classifier = xgb.XGBClassifier(**best_params)
best_xgb_classifier.fit(X_train, y_train)

# Make predictions on the test set
y_pred_xgb = best_xgb_classifier.predict(X_test)

# Evaluate the model
accuracy = accuracy_score(y_test, y_pred_xgb)
print("Accuracy for XGBoost after hyperparameter tuning:", accuracy)