import matplotlib.pyplot as plt
import pandas as pd

# Sample data
models = ['Random Forest', 'XGBoost']
accuracy_without_tuning = [0.85, 0.82]
precision_without_tuning = [0.88, 0.85]
recall_without_tuning = [0.82, 0.78]
f1_score_without_tuning = [0.85, 0.80]

accuracy_with_tuning = [0.88, 0.85]
precision_with_tuning = [0.90, 0.87]
recall_with_tuning = [0.85, 0.82]
f1_score_with_tuning = [0.87, 0.84]

# Plotting the bar graphs
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 12))

bar_width = 0.2
index = range(len(models))

# Bar graph for models without tuning
bar1 = ax1.bar(index, accuracy_without_tuning, bar_width, label='Accuracy')
bar2 = ax1.bar([i + bar_width for i in index], precision_without_tuning, bar_width, label='Precision')
bar3 = ax1.bar([i + 2 * bar_width for i in index], recall_without_tuning, bar_width, label='Recall')
bar4 = ax1.bar([i + 3 * bar_width for i in index], f1_score_without_tuning, bar_width, label='F1 Score')

ax1.set_title('Model Evaluation Metrics (Without Hyperparameter Tuning)')
ax1.set_xticks([i + 1.5 * bar_width for i in index])
ax1.set_xticklabels(models)
ax1.legend()

# Bar graph for models with tuning
bar1 = ax2.bar(index, accuracy_with_tuning, bar_width, label='Accuracy')
bar2 = ax2.bar([i + bar_width for i in index], precision_with_tuning, bar_width, label='Precision')
bar3 = ax2.bar([i + 2 * bar_width for i in index], recall_with_tuning, bar_width, label='Recall')
bar4 = ax2.bar([i + 3 * bar_width for i in index], f1_score_with_tuning, bar_width, label='F1 Score')

ax2.set_title('Model Evaluation Metrics (With Hyperparameter Tuning)')
ax2.set_xticks([i + 1.5 * bar_width for i in index])
ax2.set_xticklabels(models)
ax2.legend()

# Adjust layout
plt.tight_layout()

# Display the plot
plt.show()
