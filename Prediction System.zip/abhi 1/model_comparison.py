import pandas as pd
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.ensemble import RandomForestClassifier
import xgboost as xgb
from sklearn.model_selection import train_test_split, GridSearchCV, RandomizedSearchCV
from scipy import stats
import numpy as np
from sklearn.linear_model import LogisticRegression

# Load and preprocess your data
df = pd.read_csv('prepared.csv')
df_no_duplicates = df.drop_duplicates()
z_scores = np.abs(stats.zscore(df))
df_no_outliers = df[(z_scores < 3).all(axis=1)]
df = df_no_outliers

# Prepare the data
X = df.drop('depressed', axis=1)
y = df['depressed']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Models without hyperparameter tuning
rf_classifier = RandomForestClassifier(n_estimators=100, random_state=42)
rf_classifier.fit(X_train, y_train)

y_pred_rf = rf_classifier.predict(X_test)
accuracy_rf = accuracy_score(y_test, y_pred_rf)
precision_rf = precision_score(y_test, y_pred_rf)
recall_rf = recall_score(y_test, y_pred_rf)
f1_rf = f1_score(y_test, y_pred_rf)

xgBoost = xgb.XGBClassifier()
xgBoost.fit(X_train, y_train)

y_pred_xgb = xgBoost.predict(X_test)
accuracy_xgb = accuracy_score(y_test, y_pred_xgb)
precision_xgb = precision_score(y_test, y_pred_xgb)
recall_xgb = recall_score(y_test, y_pred_xgb)
f1_xgb = f1_score(y_test, y_pred_xgb)

model_lor = LogisticRegression()
model_lor.fit(X_train, y_train)

y_pred_lor = model_lor.predict(X_test)
accuracy_lor = accuracy_score(y_test, y_pred_lor)
precision_lor = precision_score(y_test, y_pred_lor)
recall_lor = recall_score(y_test, y_pred_lor)
f1_lor = f1_score(y_test, y_pred_lor)

# Create table without hyperparameter tuning
table_without_tuning = pd.DataFrame({
    'Model': ['Random Forest', 'XGBoost', 'Logistic Regression'],
    'Accuracy': [accuracy_rf, accuracy_xgb, accuracy_lor],
    'Precision': [precision_rf, precision_xgb, precision_lor],
    'Recall': [recall_rf, recall_xgb, recall_lor],
    'F1 Score': [f1_rf, f1_xgb, f1_lor]
})

print("Table without Hyperparameter Tuning:")
print(table_without_tuning)

# Models with hyperparameter tuning
param_grid_rf = {
    'n_estimators': [100, 200, 300],
    'max_depth': [None, 10, 20, 30],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4],
    'max_features': ['sqrt'],
    'bootstrap': [True, False]
}

grid_search_rf = GridSearchCV(estimator=rf_classifier, param_grid=param_grid_rf, cv=5, scoring='accuracy')
grid_search_rf.fit(X_train, y_train)

best_rf_classifier = grid_search_rf.best_estimator_
y_pred_rf_tuned = best_rf_classifier.predict(X_test)
accuracy_rf_tuned = accuracy_score(y_test, y_pred_rf_tuned)
precision_rf_tuned = precision_score(y_test, y_pred_rf_tuned)
recall_rf_tuned = recall_score(y_test, y_pred_rf_tuned)
f1_rf_tuned = f1_score(y_test, y_pred_rf_tuned)

param_grid_xgb = {
    'n_estimators': [100, 200, 300],
    'max_depth': [3, 4, 5],
    'learning_rate': [0.01, 0.1, 0.2],
    'subsample': [0.7, 0.8, 0.9],
}

grid_search_xgb = GridSearchCV(estimator=xgBoost, param_grid=param_grid_xgb, scoring='accuracy', cv=5)
grid_search_xgb.fit(X_train, y_train)

best_xgb_classifier = grid_search_xgb.best_estimator_
y_pred_xgb_tuned = best_xgb_classifier.predict(X_test)
accuracy_xgb_tuned = accuracy_score(y_test, y_pred_xgb_tuned)
precision_xgb_tuned = precision_score(y_test, y_pred_xgb_tuned)
recall_xgb_tuned = recall_score(y_test, y_pred_xgb_tuned)
f1_xgb_tuned = f1_score(y_test, y_pred_xgb_tuned)

# Create table with hyperparameter tuning
table_with_tuning = pd.DataFrame({
    'Model': ['Random Forest', 'XGBoost'],
    'Accuracy': [accuracy_rf_tuned, accuracy_xgb_tuned],
    'Precision': [precision_rf_tuned, precision_xgb_tuned],
    'Recall': [recall_rf_tuned, recall_xgb_tuned],
    'F1 Score': [f1_rf_tuned, f1_xgb_tuned]
})

print("\nTable with Hyperparameter Tuning:")
print(table_with_tuning)
